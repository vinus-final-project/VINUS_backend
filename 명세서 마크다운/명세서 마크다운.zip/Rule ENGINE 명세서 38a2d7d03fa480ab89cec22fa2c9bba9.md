# Rule ENGINE 명세서

## 파이프라인 위치

```
STT → RapidFuzz(Normalizer) → RuleParser → [RuleEngine | LLM 폴백] → EventExecutor
```

RuleParser가 텍스트를 ParseResult로 변환하고, RuleEngine이 ParseResult를 `List[FSMEvent]`로 번역한다. 규칙으로 해석 불가한 발화(RuleParseError)는 LLM(AiPipeline)으로 폴백한다.

## Intent 정의

| Intent | 설명 | 처리 주체 |
| --- | --- | --- |
| ORDER | 메뉴 주문·옵션·수량 | RuleEngine → FSMEvent |
| CART | 장바구니 관리 | RuleEngine → FSMEvent |
| PAYMENT | 결제 시작 | RuleEngine → FSMEvent |
| RECOMMEND | 추천 요청/수락 | RuleEngine → FSMEvent |
| INFO (type=MENU) | 메뉴 상세 정보 | RuleEngine → FSMEvent |
| SESSION | 매장/포장 선택 | RuleEngine → FSMEvent |
| CANCEL | 취소(문맥 해석: 결제취소/주문취소/세션취소) | RuleEngine → FSMEvent |
| INFO (type=MENU_LIST/OPTION_LIST/TOTAL) | 음성 메뉴판/옵션 낭독/합계 | VoicePipeline 직접 응답 (FSM 이벤트 없음) |
| NAVIGATE | 화면 이동(메뉴/결제창/페이지 넘김) | VoicePipeline 직접 응답 |
| REPEAT | 마지막 안내 재낭독("다시 들려줘") | VoicePipeline 직접 응답 |

> INFO(MENU_LIST/OPTION_LIST/TOTAL) / NAVIGATE / REPEAT 는 상태 변경이 없어 RuleEngine을 거치지 않고 VoicePipeline이 SHOW_MENU/SHOW_CART/SHOW_PAY 또는 안내 문구로 직접 응답한다.

## RuleParser 인식 규칙 (요지)

키워드·별칭 사전은 `app/ai/ruleEngine/rules.py` 정본. 발화 전 SPEECH_ALIASES로 STT 오인식 정규화("투샷"→"샷 2개", "샷투가"→"샷 추가").

| 분류 | 대표 키워드 | Intent / entities |
| --- | --- | --- |
| 메뉴 | 메뉴명(RapidFuzz 보정) | ORDER menu=m_id (2개 이상 → MultipleMenuError) |
| 필수옵션 | 아이스/핫/라지/레귤러/얼음량/당도 | ORDER required_option=[표준값] |
| 선택옵션 | 샷/바닐라·헤이즐넛·카라멜 시럽/휘핑 | ORDER optional_option=[{value,count,action}] |
| 수량 | N잔/개/컵, 한·두·세 + 단위 | ORDER quantity |
| 옵션 생략 | 그대로/완료/담아/이걸로 | ORDER skip_optional=true |
| 장바구니 | 장바구니/담은/삭제/빼/비워/하나 더 | CART action=SHOW/REMOVE/CLEAR/INCREASE/DECREASE |
| 결제 | 결제/계산/지불 | PAYMENT action=START |
| 결제수단 | 카드/현금 | NAVIGATE target=PAY method=CARD/CASH |
| 추천 | 추천 / 그걸로 / N번째 | RECOMMEND action=REQUEST/ACCEPT(index) |
| 정보 | 얼마/가격/설명/성분 | INFO type=MENU |
| 음성 메뉴판 | 메뉴 알려/커피 뭐 있어 | INFO type=MENU_LIST(category) |
| 옵션 낭독 | 시럽 뭐 있어/옵션 뭐 있어 | INFO type=OPTION_LIST(group) |
| 합계 | 합계/총 얼마/다 해서 | INFO type=TOTAL |
| 화면 이동 | 돌아가/메뉴 더/커피 메뉴 보여 | NAVIGATE target=MENU(category) |
| 페이지 | 다음/이전 (페이지) | NAVIGATE page=NEXT/PREV |
| 재낭독 | 다시 들려/뭐라고 | REPEAT |
| 주문유형 | 매장/포장 | SESSION order_type |
| 세션취소 | 처음부터/전부 취소 | SESSION action=CANCEL |
| 일반취소 | 취소 | CANCEL (문맥 해석) |

## Entity 정의

| Entity | 설명 | 예시 |
| --- | --- | --- |
| menu | 메뉴 m_id | 1 |
| quantity | 수량 | 2 |
| required_option | 단일선택(교체) 옵션 표준값 | ["ICE","라지"] |
| optional_option | 누적 옵션 목록 | [{value:"샷", count:2, action:"ADD"}] |
| skip_optional | 옵션 생략/완료 | true |
| action | 동작 | SHOW/REMOVE/CLEAR/INCREASE/DECREASE/START/REQUEST/ACCEPT/CANCEL |
| menu (CART) | 카트 대상 메뉴 m_id | 1 |
| count / option_filter | 카트 수량·옵션 필터 | 2 / ["HOT"] |
| condition | 추천 조건(발화 원문) | "달달한 거" |
| index | 추천 수락 서수 | 2 |
| type | INFO 종류 | MENU/MENU_LIST/OPTION_LIST/TOTAL |
| category / group | 카테고리 / 옵션 그룹 | "커피/라떼" / "시럽" |
| order_type | 주문 유형 | STORE/TAKEOUT |
| target / page / method | NAVIGATE 대상/페이지/결제수단 | MENU·PAY / NEXT·PREV / CARD·CASH |

## RuleEngine: ParseResult → FSMEvent

`build_events_ruleEngine_ruleEngine(db, session, parse_result)` → `List[FSMEvent]`. 옵션 값 → op_id 해석은 current_menu(또는 DB 메뉴 상세)를 참조한다(HOT/ICE op_id는 메뉴마다 다름).

| Intent | Entity 조건 | 생성 FSMEvent (순서) |
| --- | --- | --- |
| SESSION | order_type | SELECT_ORDER_TYPE |
| ORDER | menu | SELECT_MENU → (옵션) → (SET_QUANTITY) |
| ORDER | required_option | SELECT_OPTION (값별 op_id 해석) |
| ORDER | optional_option ADD | SELECT_OPTION × count |
| ORDER | optional_option REMOVE | DESELECT_OPTION × count |
| ORDER | quantity | SET_QUANTITY |
| ORDER | skip_optional | SKIP_OPTIONAL_OPTION |
| CART | action=SHOW/REMOVE/CLEAR/INCREASE/DECREASE | 대응 CART 이벤트 (cart_item_id 해석) |
| PAYMENT | action=START | START_PAYMENT |
| RECOMMEND | action=REQUEST / ACCEPT | REQUEST_RECOMMENDATION / ACCEPT_RECOMMENDATION(index) |
| INFO | type=MENU | REQUEST_MENU_INFO |
| SESSION/CANCEL | action=CANCEL | 문맥 해석: PAYMENT→PAYMENT_CANCEL, 작성중→CANCEL_ORDER_ITEM, 그 외→CANCEL_SESSION |

- 옵션은 필수/선택 구분 없이 자유선택 → 모두 SELECT_OPTION(+1)/DESELECT_OPTION(-1)로 매핑(누적).
- 단일선택 그룹(og_max==1)은 controller가 교체 처리.

## RuleEngine 공개 메서드

| 메서드 | 반환 | 설명 |
| --- | --- | --- |
| build_events_ruleEngine_ruleEngine(db, session, parse_result) | List[FSMEvent] | 인텐트별 이벤트 조립 (해석 실패 → RuleParseError) |
| build_order_echo_ruleEngine_ruleEngine(db, session, entities) | str \| None | ORDER 발화 요약 에코("아메리카노 두 잔 담았어요") — 한 발화가 여러 이벤트로 번역될 때 대표 안내 |
| composing_block_msg_ruleEngine_ruleEngine(session) | str | 작성 중 주문 이탈 차단 안내 |
| option_guide_msg_ruleEngine_ruleEngine(menu) | str | 현재 메뉴 옵션 그룹 안내 |

## LLM 폴백 정책

| 예외 | 처리 |
| --- | --- |
| RuleParseError (능력 부족: 해석 불가/문맥 참조/옵션 불명확) | LLM(AiPipeline) 1차 폴백 → 실패 시 규칙 안내 문구 2차 폴백 |
| MultipleMenuError (메뉴 2개 이상) | LLM 아님 — "한 번에 한 메뉴씩 주문해 주세요." 즉시 안내 |
| PolicyBlockedError (작성 중 화면 이탈 등) | LLM 아님 — 정책 안내 즉시 반환 |

LLM(AiPipeline)은 세션 상태(fsm_state/order_type/order_item/cart)를 동봉해 AI 서버 호출 → LLMResponse.events를 FSMEvent로 변환(Event enum에 없는 타입은 무시). SELECT_MENU 2개 이상이면 정책 차단.

## 실행/시스템 정책

| 항목 | 정책 |
| --- | --- |
| 입력 | ParseResult (RULE 또는 LLM) |
| 출력 | List[FSMEvent] |
| 한 번에 처리 메뉴/Intent/행동 | 각 1개 |
| 옵션 개수 | SELECT_OPTION 반복(누적) / DESELECT_OPTION 감소 |
| op_id 해석 | current_menu 스냅샷 또는 DB 메뉴 상세 |
| Event 실행 | EventExecutor가 FIFO |
| Rollback | 없음 |

## 처리 예시

| 사용자 입력 | ParseResult | RuleEngine 결과 |
| --- | --- | --- |
| 아메리카노 하나 | ORDER(menu, quantity=1) | SELECT_MENU → SET_QUANTITY |
| 아이스 아메리카노 | ORDER(menu, required_option=[ICE]) | SELECT_MENU → SELECT_OPTION(ICE) |
| 아메리카노 샷 두 개 | ORDER(menu, optional_option=[{샷,2,ADD}]) | SELECT_MENU → SELECT_OPTION×2 |
| 휘핑 빼줘 | ORDER(optional_option=[{휘핑,1,REMOVE}]) | DESELECT_OPTION(휘핑) |
| 그대로 담아줘 | ORDER(skip_optional=true) | SKIP_OPTIONAL_OPTION |
| 아메리카노 두 잔 주세요 | ORDER(menu, quantity=2) | SELECT_MENU → SET_QUANTITY |
| 장바구니 비워 | CART(action=CLEAR) | CLEAR_CART |
| 아메리카노 하나 더 | CART(action=INCREASE) | INCREASE_CART_ITEM |
| 결제할게 | PAYMENT(action=START) | START_PAYMENT |
| 달달한 거 추천 | RECOMMEND(action=REQUEST) | REQUEST_RECOMMENDATION |
| 두 번째 걸로 | RECOMMEND(action=ACCEPT, index=2) | ACCEPT_RECOMMENDATION |
| 아메리카노 얼마야 | INFO(type=MENU) | REQUEST_MENU_INFO |
| 처음부터 | SESSION(action=CANCEL) | CANCEL_SESSION |
| 커피 뭐 있어 | INFO(type=MENU_LIST) | (VoicePipeline 낭독 응답 — FSM 이벤트 없음) |
| 다시 들려줘 | REPEAT | (VoicePipeline 재낭독 — FSM 이벤트 없음) |
