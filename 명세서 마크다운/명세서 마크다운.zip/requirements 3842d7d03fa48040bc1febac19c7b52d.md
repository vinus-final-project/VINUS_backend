# requirements

## backend requirements

**웹/서버**

- fastapi - API 서버 (+ starlette, WebSocket)
- uvicorn - ASGI 서버 실행
- python-multipart - 폼/파일 처리

**DB**

- sqlalchemy - ORM (async)
- asyncmy - 비동기 MySQL 드라이버 (런타임)
- pymysql - 동기 MySQL 드라이버 (alembic 등)
- alembic - 마이그레이션
- greenlet - SQLAlchemy async 실행

**설정/검증**

- pydantic - Request/Response 검증
- pydantic-settings - 환경변수 설정
- python-dotenv - .env 로드

**결제**

- httpx - 토스페이먼츠 API 호출

**음성 파이프라인**

- faster-whisper - STT (large-v3-turbo) (+ ctranslate2, av, onnxruntime, tokenizers, huggingface_hub)
- numpy - PCM 처리
- rapidfuzz - 메뉴/옵션명 보정 (Normalizer)
- webrtcvad - 백엔드 VAD (발화 구간 분리)

> 참고: JWT/비밀번호 암호화(python-jose, passlib)는 현재 인증 미구현으로 사용하지 않음. 실제 핀 목록은 requirements.txt 정본.

## frontend requirements

**코어**

- react / react-dom - 프론트 메인 (v19)
- react-router-dom - 화면 라우팅 (v7)
- typescript - 타입 검사
- vite - 개발/빌드 서버

**통신/결제**

- axios - 백엔드 HTTP 통신
- @tosspayments/tosspayments-sdk - 토스 결제

**Android / 하드웨어 (Capacitor)**

- @capacitor/core, @capacitor/android, @capacitor/app, @capacitor/cli - 안드로이드 빌드/네이티브 브리지
- @capacitor-community/text-to-speech - TTS 음성 안내 (네이티브, 브라우저 Web Speech API 병행)
- @atomsolution/usb-printer-capacitor - 영수증 USB 프린터

**UI/기타**

- react-icons - 아이콘
- sweetalert2 - 알림 모달
- wanted-sans - 폰트

> 프론트 VAD(@ozymandiasthegreat/vad)는 제거됨 — VAD는 백엔드 VadSegmenter로 이관. TTS는 클라이언트에서 처리(서버 음성 템플릿 DB 미사용).
