# STT / RapidFuzz 명세서

## VAD (백엔드 발화 구간 분리)

프론트는 마이크 PCM(16kHz mono Int16)을 **연속 스트림**으로 WebSocket 전송하고, 백엔드 `VadSegmenter`(webrtcvad 기반)가 발화 구간을 잘라 STT로 넘긴다. (프론트 VAD는 폐기, 백엔드 이관 완료)

| 항목 | 내용 |
| --- | --- |
| 모듈 | app/ai/vad/vadService.py — VadSegmenter |
| 입력 | 연속 PCM 청크 (WebSocket Binary) |
| 출력 | 완성된 발화(utterance) PCM bytes 목록 |
| 판정 | 연속 음성/무음 프레임 수로 발화 시작·종료 (pre-roll 포함) |
| 폐기 | 0.5초 미만 발화는 잡음으로 폐기 |

## STT 처리 명세

| 항목 | 내용 |
| --- | --- |
| 모듈 | app/ai/stt/whisperService.py |
| 입력 | 발화 PCM bytes (VadSegmenter 출력) |
| 출력 | 한국어 텍스트 (str) |
| 모델 | faster-whisper (large-v3-turbo), CUDA 있으면 float16 / 없으면 int8 |
| 호출 시점 | VadSegmenter가 발화 완성 시 |
| 힌트 | initial_prompt에 실제 메뉴/옵션명 주입(인식률 향상) |
| 환각 방어 | condition_on_previous_text=False, 환각 필터 → 빈/무의미 발화는 "" 반환 |
| 다음 처리 | RapidFuzz(Normalizer) |
| 빈 결과 | VoicePipeline이 응답 없이 조용히 무시(폐기) |

### STT 메서드

| Method | 입력 | 출력 | 설명 |
| --- | --- | --- | --- |
| transcribe_stt_whisper | pcm_bytes, sample_rate=16000 | str | 발화 PCM → 한국어 텍스트 (비동기, to_thread) |
| get_model_stt_whisper | - | WhisperModel | 모델 lazy 로드(싱글톤, 앱 기동 시 웜업) |

## RapidFuzz (Normalizer) 처리 명세

| 항목 | 내용 |
| --- | --- |
| 모듈 | app/ai/rapidfuzz/normalizer.py |
| 입력 | STT 텍스트 |
| 출력 | 보정된 텍스트 |
| 처리 방식 | 한글 자모 분해 후 fuzzy matching (메뉴/옵션명 사전 대조) |
| 사전 | rapidfuzz/menus.csv, options.csv (import 시 1회 로드) |
| 임계값 | 자모 유사도 85 이상, n-gram(최대 3어절) 묶음 매칭 |
| 실패 시 | 매칭 없으면 원본 텍스트 그대로 전달 |
| 다음 처리 | RuleParser |

### RapidFuzz 메서드

| Method | 입력 | 출력 | 설명 |
| --- | --- | --- | --- |
| normalize_rapidfuzz_normalizer | text | str | 메뉴명·옵션명 오인식 표준명 치환 (비동기) |

## STT + RapidFuzz 전체 흐름

| 단계 | 입력 | 처리 | 출력 |
| --- | --- | --- | --- |
| 1 | 연속 PCM 스트림 | VadSegmenter | 발화 PCM |
| 2 | 발화 PCM | STT(faster-whisper) | 텍스트 |
| 3 | 텍스트 | RapidFuzz | 보정 텍스트 |
| 4 | 보정 텍스트 | RuleParser | ParseResult |
