# Event Executor 명세서

## 개요

Rule Engine/LLM이 생성한 `List[FSMEvent]`를 FIFO로 실행하고 최종 `SessionResponse`를 조립한다. 각 이벤트는 Dispatcher(validator + controller + 상태전이)로 위임한다. 실패 시 즉시 중단하며 Rollback은 없다.

## 인터페이스

| 메서드 | 입력 | 반환 | 설명 |
| --- | --- | --- | --- |
| execute_ruleEngine_eventExecutor | db, session, events: List[FSMEvent], message: str \| None | SessionResponse | Event List FIFO 실행 → 응답 조립 |

- `message`: RuleEngine/LLM이 생성한 **정상 안내 문구**(선택). 성공 시 session.message에 반영.
- 터치 라우터는 message 없이 호출 → 정상 응답의 message는 None(또는 Controller가 세팅한 값).

## 처리 흐름

| 단계 | 처리 |
| --- | --- |
| 1 | 실행 시작 시 `session.message = None` (이전 턴 문구 잔류 방지) |
| 2 | events를 FIFO로 순회 |
| 3 | 각 이벤트 → `Dispatcher.dispatch()` (transition 검사 + validator + controller + 상태전이) |
| 4 | 예외 발생 시 → 즉시 중단, ERROR 응답 조립 후 반환 |
| 5 | 전부 성공 → 호출자 `message`가 있으면 session.message에 적용 (없으면 Controller가 세팅한 문구 유지, 예: 추천) |
| 6 | 성공 응답 조립 |
| 7 | 응답 종류 후처리(override): 결제취소/장바구니 이벤트 표기 |
| 8 | last_active_at 갱신(TTL) + AI 안내 문구 세션 로그·last_message 적재 |
| 9 | SessionResponse 반환 |

## 응답 종류(response_type) 결정

**성공 응답 (_build_success)**

| 조건 | response_type |
| --- | --- |
| fsm_state == COMPLETE | PAYMENT_SUCCESS |
| session_status != ACTIVE (종료) | SESSION_END |
| 그 외 | NORMAL |

**후처리 override (execute 말미)**

| 조건 | response_type |
| --- | --- |
| events에 PAYMENT_CANCEL 포함 | PAYMENT_CANCEL (프론트 /cart 복귀) |
| events에 장바구니 이벤트(SHOW/REMOVE/CLEAR/INCREASE/DECREASE_CART) 포함 | SHOW_CART (카트 화면 유지) |

> 음성 메뉴 낭독/화면 이동(SHOW_MENU/SHOW_PAY)은 EventExecutor가 아니라 **VoicePipeline이 직접 SessionResponse를 조립**해 반환한다(FSM 이벤트 없이).

**에러 응답 (_build_error)**

| 필드 | 값 |
| --- | --- |
| response_type | ERROR |
| error_code | str(예외) = 표준 실패 코드 |
| message | errorMessage.py ERROR_MESSAGES[error_code] (없으면 기본 문구) |
| success | false |

## message 처리 정책

| 항목 | 정책 |
| --- | --- |
| 턴 시작 | session.message = None으로 초기화 (잔류 방지) |
| 정상 문구 출처 | RuleEngine/LLM 전달 message > Controller가 세팅한 문구(추천 등) |
| 오류 문구 출처 | error_code → errorMessage 맵 (RuleEngine/LLM 문구 무시) |
| last_message | AI 안내 문구가 있으면 저장 → "다시 들려줘"(REPEAT) 재낭독용 |
| 세션 로그 | AI 안내 문구는 SpeakerType.AI로 로그 적재 |

## 실행 정책

| 항목 | 정책 |
| --- | --- |
| Event Queue | FIFO |
| Validation / Controller / Session 갱신 | Dispatcher(FSM)가 수행 |
| Event 실패 | 즉시 중단 + ERROR 응답 |
| Rollback | 수행하지 않음 |
| Event 없음 | 현재 세션 상태로 정상 응답 즉시 반환 |
| TTL | 매 실행 종료 시 last_active_at 갱신 |

## 입력 예시 (한 발화 → 여러 이벤트)

"아이스 아메리카노 두 잔" →

| 실행 순서 | Event |
| --- | --- |
| ① | SELECT_MENU |
| ② | SELECT_OPTION (ICE) |
| ③ | SET_QUANTITY (2) |
